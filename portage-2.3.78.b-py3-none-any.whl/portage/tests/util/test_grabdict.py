# test_grabDict.py -- Portage Unit Testing Functionality
# Copyright 2006-2010 Gentoo Foundation
# Distributed under the terms of the GNU General Public License v2

from portage.tests import TestCase
#from portage.util import grabdict

class GrabDictTestCase(TestCase):
	
	def testGrabDictPass(self):
		pass
